import { Context } from "@deepseek-ai/cordis";
declare const inject: string[];
declare function apply(ctx: Context): void;
export { apply, inject };
//# sourceMappingURL=client.d.ts.map